<table class="table">
    <thead>
        <tr>
            <th>SL.NO</th>
            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th height="30" style="text-align:center;vertical-align: middle;font-size: 16px; font-weight: bold"
                    colspan="<?php echo e(count($module->items)); ?>">
                    <?php echo e(strtoupper($module->name)); ?>

                </th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <tr style="border-bottom: 2px solid #00000; vertical-align: middle">
            <th></th>
            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($module2->items) > 0): ?>
                    <?php $__currentLoopData = $module2->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th height="20" style="vertical-align: middle"><?php echo e(strtoupper($item->label)); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <th></th>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </thead>
    <tbody>
        <?php if(count($students) > 0): ?>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($module3->itemUsers()->exists()): ?>
                            <?php if($module3->isRepeatable()): ?>
                                <?php
                                // get latest group
                                $itemGroup = $module3->itemGroups()->where('user_id', $student->id)->latest()->first();
                                ?>
                                <?php if($itemGroup && $itemGroup->itemUsers): ?>
                                    <?php $__currentLoopData = $itemGroup->orderedItemUsers(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($itemUser->getValue()); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php $__currentLoopData = $module3->orderedItemUsers(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($itemUser->getValue()); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php else: ?>
                            <td></td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\dhocp\resources\views/exports/students.blade.php ENDPATH**/ ?>